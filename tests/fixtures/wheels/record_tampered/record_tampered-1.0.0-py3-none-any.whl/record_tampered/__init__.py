"""record_tampered fixture package."""
VALUE = 2
